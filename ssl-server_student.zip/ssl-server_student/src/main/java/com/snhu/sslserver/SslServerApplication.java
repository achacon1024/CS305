package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;

@SpringBootApplication
@RestController
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
    
    @GetMapping("/hash")
    public String hash(@RequestParam(value = "name", defaultValue = "World") String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(data.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return "<html><body>" +
                   "<h1>Artemis Financial - Checksum Verification</h1>" +
                   "<p><strong>Developer:</strong> Andrew</p>" +
                   "<p><strong>Data:</strong> " + data + "</p>" +
                   "<p><strong>SHA-256 Checksum:</strong> " + hexString.toString() + "</p>" +
                   "</body></html>";
        } catch (Exception e) {
            return "Error generating checksum: " + e.getMessage();
        }
    }
}